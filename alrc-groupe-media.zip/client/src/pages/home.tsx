import { motion } from "framer-motion";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import HeroSection from "@/components/hero-section";
import ServiceCard from "@/components/service-card";
import TeamMember from "@/components/team-member";
import PortfolioItem from "@/components/portfolio-item";
import ContactForm from "@/components/contact-form";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const services = [
  {
    id: "strategic",
    title: "Communication Stratégique",
    description: "Stratégie personnalisée, gestion de crise, influence et protection de réputation.",
    icon: "🎯",
    gradient: "from-gold to-yellow-300"
  },
  {
    id: "digital",
    title: "Digital & Réseaux Sociaux",
    description: "Gestion des réseaux sociaux, stratégie digitale et e-réputation.",
    icon: "📱",
    gradient: "from-blue-500 to-blue-300"
  },
  {
    id: "creative",
    title: "Création & Design",
    description: "Design d'espaces, innovation créative et développement d'identité visuelle.",
    icon: "🎨",
    gradient: "from-purple-500 to-purple-300"
  },
  {
    id: "hr",
    title: "Solutions RH",
    description: "Recrutement ALRC Emploi, développement professionnel et conseil RH.",
    icon: "👥",
    gradient: "from-green-500 to-green-300"
  },
  {
    id: "web",
    title: "Web & Hébergement",
    description: "ALRC WebSphere : création de sites, hébergement sécurisé et support technique.",
    icon: "💻",
    gradient: "from-blue-600 to-blue-400"
  },
  {
    id: "education",
    title: "Services Éducatifs",
    description: "Webinaires interactifs, formation professionnelle et voyages éducatifs.",
    icon: "🎓",
    gradient: "from-orange-500 to-orange-300"
  },
  {
    id: "financial",
    title: "Conseil Financier",
    description: "Conseil financier, intermédiation et structuration de projets bancaires.",
    icon: "📊",
    gradient: "from-yellow-500 to-yellow-300"
  },
  {
    id: "technology",
    title: "Intégration Technologique",
    description: "Intelligence artificielle, développement d'applications et solutions mobiles.",
    icon: "🤖",
    gradient: "from-red-500 to-red-300"
  }
];

const teamMembers = [
  {
    name: "Alexandre Rocher",
    role: "Directeur Général",
    description: "15 ans d'expérience en communication stratégique et innovation.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "👑"
  },
  {
    name: "Sophie Marchand",
    role: "Directrice Créative",
    description: "Experte en design et stratégie de marque, ancienne TBWA.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "🎨"
  },
  {
    name: "Thomas Dubois",
    role: "Directeur Technique",
    description: "Architecte de solutions digitales et expert en IA.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "💻"
  },
  {
    name: "Marine Laurent",
    role: "Responsable Développement",
    description: "Spécialiste en stratégie commerciale et relations clients.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b332c62c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "📈"
  }
];

const portfolioItems = [
  {
    title: "Transformation Digitale - Groupe Élan",
    category: "STRATÉGIE DIGITALE",
    description: "Refonte complète de l'identité digitale avec une augmentation de 250% de la visibilité en ligne.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-navy to-blue-500"
  },
  {
    title: "Rebranding - Tech Innovate",
    category: "IDENTITÉ VISUELLE",
    description: "Création d'une identité visuelle premium qui a propulsé la startup vers une levée de fonds réussie.",
    image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-purple-500 to-pink-400"
  },
  {
    title: "Protection Réputation - Luxury Hotels",
    category: "GESTION DE CRISE",
    description: "Stratégie de communication de crise qui a restauré la confiance et augmenté les réservations de 180%.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-green-500 to-blue-500"
  }
];

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <HeroSection />

      {/* Company Introduction */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-8">
                L'Excellence au Service de Votre <span className="text-gold">Réussite</span>
              </h2>
              <p className="text-lg text-charcoal mb-8 leading-relaxed">
                Basée à Paris depuis plus de 5 ans, ALRC Groupe Média (Agence Le Rocher Communication) 
                est votre partenaire de confiance pour une communication stratégique intégrée. 
                Notre approche unique combine expertise technique et vision stratégique.
              </p>
              <div className="grid grid-cols-3 gap-8 mb-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold mb-2">500+</div>
                  <div className="text-sm text-charcoal font-medium">Clients Satisfaits</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold mb-2">1200+</div>
                  <div className="text-sm text-charcoal font-medium">Projets Réalisés</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold mb-2">8</div>
                  <div className="text-sm text-charcoal font-medium">Expertises</div>
                </div>
              </div>
              <blockquote className="italic text-charcoal border-l-4 border-gold pl-6">
                "Travailler avec ALRC Groupe Média a été un véritable tournant. 
                Leur approche stratégique et humaine a boosté notre visibilité en quelques semaines."
                <cite className="block mt-2 text-sm font-semibold">- Alain K., Directeur Communication, Groupe Élan</cite>
              </blockquote>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Bureau moderne ALRC Groupe avec design élégant" 
                className="rounded-2xl luxury-shadow w-full h-auto" 
              />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl p-6 luxury-shadow">
                <div className="text-2xl font-bold text-navy mb-1">24/7</div>
                <div className="text-sm text-charcoal">Support Client</div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Nos 8 Expertises <span className="text-gold">Intégrées</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Une plateforme unique qui centralise plus de 10 domaines d'expertise 
              pour répondre à tous vos besoins en communication et développement.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <ServiceCard service={service} />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button className="bg-gold text-navy hover:bg-gold/90 px-8 py-4 text-lg">
                Découvrir Tous nos Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Nos <span className="text-gold">Réalisations</span> d'Exception
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Découvrez comment nous avons transformé les défis de nos clients en succès mesurables.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {portfolioItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <PortfolioItem item={item} />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/portfolio">
              <Button className="bg-gold text-navy hover:bg-gold/90 px-8 py-4 text-lg">
                Voir Tous nos Projets
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="equipe" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Notre Équipe <span className="text-gold">d'Experts</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Des professionnels passionnés qui allient expertise technique et vision stratégique 
              pour faire de vos projets des succès durables.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <TeamMember member={member} />
              </motion.div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/about">
              <Button variant="outline" className="border-gold text-gold hover:bg-gold hover:text-navy px-8 py-4 text-lg">
                Découvrir Notre Histoire
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-navy relative">
        <div className="absolute inset-0 opacity-10">
          <img 
            src="https://images.unsplash.com/photo-1497366412874-3415097a27e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
            alt="Intérieur de bureau luxueux" 
            className="w-full h-full object-cover" 
          />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-8">
                Transformons Ensemble Vos <span className="text-gold">Ambitions</span>
              </h2>
              <p className="text-xl text-gray-300 mb-12">
                Bénéficiez d'une consultation gratuite avec nos experts. 
                Nous analysons vos besoins et vous proposons une stratégie sur mesure.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy">📍</span>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold mb-2">Nos Bureaux</h4>
                    <p className="text-gray-300">142 rue de Rivoli, 75015 Paris</p>
                    <p className="text-gray-300">4 Rue Aristide Maillol, 75015 Paris</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy">📞</span>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold mb-2">Contact Direct</h4>
                    <p className="text-gray-300">+33 7 67 03 48 XX</p>
                    <p className="text-gray-300">Disponible 24/7</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy">✉️</span>
                  </div>
                  <div>
                    <h4 className="text-white font-semibold mb-2">Email</h4>
                    <p className="text-gray-300">contact@groupe-alrc.org</p>
                    <p className="text-gray-300">Réponse sous 2h</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <ContactForm />
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
