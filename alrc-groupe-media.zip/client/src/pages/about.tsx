import { motion } from "framer-motion";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import TeamMember from "@/components/team-member";
import StatsCounter from "@/components/stats-counter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const teamMembers = [
  {
    name: "Alexandre Rocher",
    role: "Directeur Général",
    description: "15 ans d'expérience en communication stratégique et innovation. Diplômé d'HEC Paris.",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "👑"
  },
  {
    name: "Sophie Marchand",
    role: "Directrice Créative",
    description: "Experte en design et stratégie de marque, ancienne directrice créative chez TBWA Paris.",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "🎨"
  },
  {
    name: "Thomas Dubois",
    role: "Directeur Technique",
    description: "Architecte de solutions digitales et expert en IA, ancien lead developer chez Criteo.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "💻"
  },
  {
    name: "Marine Laurent",
    role: "Responsable Développement",
    description: "Spécialiste en stratégie commerciale et relations clients, MBA INSEAD.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b332c62c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
    icon: "📈"
  }
];

const values = [
  {
    title: "Excellence",
    description: "Nous visons l'excellence dans chaque projet, en dépassant les attentes de nos clients.",
    icon: "⭐"
  },
  {
    title: "Innovation",
    description: "Nous restons à la pointe des tendances et technologies pour offrir des solutions innovantes.",
    icon: "🚀"
  },
  {
    title: "Proximité",
    description: "Nous privilégions une relation de confiance et de proximité avec nos clients.",
    icon: "🤝"
  },
  {
    title: "Résultats",
    description: "Nous nous engageons sur des résultats mesurables et un retour sur investissement tangible.",
    icon: "📊"
  }
];

export default function About() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-b from-navy to-charcoal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">
              À Propos d'<span className="text-gold">ALRC Groupe</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
              Découvrez l'histoire, les valeurs et l'équipe qui font de nous 
              votre partenaire de confiance en communication stratégique.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-8">
                Notre <span className="text-gold">Histoire</span>
              </h2>
              <div className="space-y-6 text-lg text-charcoal">
                <p>
                  Fondée en 2019, ALRC Groupe Média (Agence Le Rocher Communication) 
                  est née de la vision de créer une agence de communication intégrée, 
                  capable de répondre à tous les besoins des entreprises modernes.
                </p>
                <p>
                  Basée au cœur de Paris, notre agence s'est rapidement imposée comme 
                  un acteur incontournable de la communication stratégique en France. 
                  Avec plus de 500 clients satisfaits et 1200 projets réalisés, 
                  nous continuons d'innover pour offrir des solutions toujours plus performantes.
                </p>
                <p>
                  Notre approche unique combine expertise technique, créativité et 
                  vision stratégique pour transformer les défis de nos clients en 
                  opportunités de croissance durable.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="Équipe ALRC Groupe en réunion stratégique" 
                className="rounded-2xl luxury-shadow w-full h-auto" 
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Nos <span className="text-gold">Valeurs</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Ces quatre piliers guident chacune de nos actions et définissent 
              notre engagement envers nos clients.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="text-center p-8 luxury-shadow hover-lift">
                  <CardContent className="pt-6">
                    <div className="text-4xl mb-4">{value.icon}</div>
                    <h3 className="text-xl font-serif font-bold text-navy mb-4">
                      {value.title}
                    </h3>
                    <p className="text-charcoal">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Notre Équipe <span className="text-gold">d'Experts</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Rencontrez les talents qui donnent vie à vos projets les plus ambitieux.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <TeamMember member={member} />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-navy">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-white mb-6">
              ALRC en <span className="text-gold">Chiffres</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-4 gap-8">
            <StatsCounter target={500} label="Clients Satisfaits" suffix="+" />
            <StatsCounter target={1200} label="Projets Réalisés" suffix="+" />
            <StatsCounter target={5} label="Années d'Expérience" suffix="+" />
            <StatsCounter target={8} label="Expertises Intégrées" />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-navy mb-6">
              Rejoignez nos <span className="text-gold">Clients Satisfaits</span>
            </h2>
            <p className="text-xl text-charcoal mb-8">
              Découvrez comment notre expertise peut transformer votre communication 
              et accélérer votre croissance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button className="bg-gold text-navy hover:bg-gold/90 px-8 py-4 text-lg">
                  Consultation Gratuite
                </Button>
              </Link>
              <Link href="/portfolio">
                <Button variant="outline" className="border-navy text-navy hover:bg-navy hover:text-white px-8 py-4 text-lg">
                  Voir nos Réalisations
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
