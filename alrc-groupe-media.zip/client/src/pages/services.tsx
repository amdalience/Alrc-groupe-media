import { motion } from "framer-motion";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import ServiceCard from "@/components/service-card";
import SkillBadge from "@/components/skill-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const services = [
  {
    id: "strategic",
    title: "Communication Stratégique & Gestion de Crise",
    description: "Stratégie personnalisée, gestion de crise, influence et protection de réputation.",
    icon: "🎯",
    gradient: "from-gold to-yellow-300",
    details: [
      "Développement de stratégies de communication sur mesure",
      "Communication corporate et institutionnelle",
      "Gestion de crise et protection de réputation",
      "Conseil en image et influence"
    ]
  },
  {
    id: "digital",
    title: "Digital & Réseaux Sociaux",
    description: "Gestion des réseaux sociaux, stratégie digitale et e-réputation.",
    icon: "📱",
    gradient: "from-blue-500 to-blue-300",
    details: [
      "Gestion et optimisation des réseaux sociaux",
      "Mise en place de stratégies digitales",
      "Gestion de l'e-réputation",
      "Création de contenus engageants"
    ]
  },
  {
    id: "creative",
    title: "Création & Design",
    description: "Design d'espaces, innovation créative et développement d'identité visuelle.",
    icon: "🎨",
    gradient: "from-purple-500 to-purple-300",
    details: [
      "Design d'espaces et aménagement",
      "Solutions d'innovation créative",
      "Développement d'identité visuelle",
      "Création graphique et branding"
    ]
  },
  {
    id: "hr",
    title: "Solutions Ressources Humaines",
    description: "Recrutement ALRC Emploi, développement professionnel et conseil RH.",
    icon: "👥",
    gradient: "from-green-500 to-green-300",
    details: [
      "Recrutement et placement de talents (ALRC Emploi)",
      "Développement professionnel et formation",
      "Conseil RH et solutions innovantes",
      "Gestion des ressources humaines"
    ]
  },
  {
    id: "web",
    title: "Développement Web & Hébergement",
    description: "ALRC WebSphere : création de sites, hébergement sécurisé et support technique.",
    icon: "💻",
    gradient: "from-blue-600 to-blue-400",
    details: [
      "Enregistrement de domaines et hébergement sécurisé",
      "Création de sites web clés en main",
      "Support technique et maintenance",
      "Solutions complètes de présence digitale"
    ]
  },
  {
    id: "education",
    title: "Services Éducatifs",
    description: "Webinaires interactifs, formation professionnelle et voyages éducatifs.",
    icon: "🎓",
    gradient: "from-orange-500 to-orange-300",
    details: [
      "Webinaires interactifs et formation à distance",
      "Sessions de formation professionnelle",
      "Programmes de voyages éducatifs et culturels",
      "Développement de compétences"
    ]
  },
  {
    id: "financial",
    title: "Conseil Financier",
    description: "Conseil financier, intermédiation et structuration de projets bancaires.",
    icon: "📊",
    gradient: "from-yellow-500 to-yellow-300",
    details: [
      "Conseil financier et intermédiation",
      "Assistance à l'accès au financement",
      "Assurance risques et structuration de projets bancaires",
      "Stratégies d'investissement"
    ]
  },
  {
    id: "technology",
    title: "Intégration Technologique",
    description: "Intelligence artificielle, développement d'applications et solutions mobiles.",
    icon: "🤖",
    gradient: "from-red-500 to-red-300",
    details: [
      "Mise en place d'intelligence artificielle",
      "Développement d'applications personnalisées",
      "Solutions mobiles et applications",
      "Intégration de technologies innovantes"
    ]
  }
];

export default function Services() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-b from-navy to-charcoal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">
              Nos <span className="text-gold">Services</span> Premium
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
              8 expertises intégrées pour répondre à tous vos besoins en communication 
              et développement d'entreprise
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12">
            {services.map((service, index) => (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="h-full luxury-shadow premium-border hover-lift">
                  <CardHeader>
                    <div className={`w-16 h-16 bg-gradient-to-br ${service.gradient} rounded-full flex items-center justify-center mb-6`}>
                      <span className="text-2xl">{service.icon}</span>
                    </div>
                    <CardTitle className="text-2xl font-serif text-navy mb-4">
                      {service.title}
                    </CardTitle>
                    <p className="text-charcoal text-lg">
                      {service.description}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3 mb-8">
                      {service.details.map((detail, i) => (
                        <li key={i} className="flex items-start space-x-3">
                          <span className="text-gold mt-1">✓</span>
                          <span className="text-charcoal">{detail}</span>
                        </li>
                      ))}
                    </ul>
                    <Link href="/contact">
                      <Button className="w-full bg-gold text-navy hover:bg-gold/90">
                        Demander un Devis
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Expertise Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Notre <span className="text-gold">Expertise</span> Technique
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto mb-12">
              Technologies et méthodes que nous maîtrisons pour transformer vos projets
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-12">
            <div>
              <h3 className="text-2xl font-serif font-bold text-navy mb-6">Communication & Marketing</h3>
              <div className="flex flex-wrap gap-3">
                <SkillBadge skill="Stratégie de marque" delay={0} />
                <SkillBadge skill="Relations publiques" delay={0.1} />
                <SkillBadge skill="Marketing digital" delay={0.2} />
                <SkillBadge skill="Gestion de crise" delay={0.3} />
                <SkillBadge skill="Influence marketing" delay={0.4} />
                <SkillBadge skill="E-réputation" delay={0.5} />
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-serif font-bold text-navy mb-6">Technologies</h3>
              <div className="flex flex-wrap gap-3">
                <SkillBadge skill="Intelligence Artificielle" delay={0.1} />
                <SkillBadge skill="Développement Web" delay={0.2} />
                <SkillBadge skill="Applications Mobiles" delay={0.3} />
                <SkillBadge skill="Cloud Computing" delay={0.4} />
                <SkillBadge skill="Cybersécurité" delay={0.5} />
                <SkillBadge skill="Data Analytics" delay={0.6} />
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-serif font-bold text-navy mb-6">Business & Finance</h3>
              <div className="flex flex-wrap gap-3">
                <SkillBadge skill="Conseil financier" delay={0.2} />
                <SkillBadge skill="Levée de fonds" delay={0.3} />
                <SkillBadge skill="Stratégie RH" delay={0.4} />
                <SkillBadge skill="Formation" delay={0.5} />
                <SkillBadge skill="Audit organisationnel" delay={0.6} />
                <SkillBadge skill="Transformation digitale" delay={0.7} />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Prêt à Transformer Votre <span className="text-gold">Communication</span> ?
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Contactez-nous pour une consultation gratuite et découvrez comment 
              nos expertises peuvent propulser votre entreprise.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button className="bg-gold text-navy hover:bg-gold/90 px-8 py-4 text-lg">
                  Consultation Gratuite
                </Button>
              </Link>
              <Link href="/portfolio">
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-navy px-8 py-4 text-lg">
                  Voir nos Réalisations
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
