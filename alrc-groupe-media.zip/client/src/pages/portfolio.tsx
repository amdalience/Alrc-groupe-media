import { useState } from "react";
import { motion } from "framer-motion";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import PortfolioItem from "@/components/portfolio-item";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

const portfolioItems = [
  {
    title: "Transformation Digitale - Groupe Élan",
    category: "STRATÉGIE DIGITALE",
    description: "Refonte complète de l'identité digitale avec une augmentation de 250% de la visibilité en ligne et 180% d'engagement sur les réseaux sociaux.",
    image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-navy to-blue-500",
    results: ["250% d'augmentation de visibilité", "180% d'engagement social", "15% de croissance du CA"]
  },
  {
    title: "Rebranding - Tech Innovate",
    category: "IDENTITÉ VISUELLE",
    description: "Création d'une identité visuelle premium qui a propulsé la startup vers une levée de fonds de 2M€ réussie.",
    image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-purple-500 to-pink-400",
    results: ["Levée de fonds 2M€", "Reconnaissance industrie", "Brand awareness +300%"]
  },
  {
    title: "Protection Réputation - Luxury Hotels",
    category: "GESTION DE CRISE",
    description: "Stratégie de communication de crise qui a restauré la confiance et augmenté les réservations de 180%.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-green-500 to-blue-500",
    results: ["180% de réservations", "Restauration confiance", "E-réputation positive"]
  },
  {
    title: "Stratégie RH - Global Corp",
    category: "SOLUTIONS RH",
    description: "Restructuration complète de la communication interne et externe RH, optimisation des processus de recrutement.",
    image: "https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-green-600 to-teal-500",
    results: ["50% temps de recrutement", "95% satisfaction employés", "Réduction turnover 40%"]
  },
  {
    title: "Plateforme E-commerce - Fashion Brand",
    category: "DÉVELOPPEMENT WEB",
    description: "Création d'une plateforme e-commerce complète avec intégration IA pour personnalisation shopping.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-pink-500 to-rose-400",
    results: ["Ventes en ligne +400%", "Conversion rate 12%", "Customer retention 85%"]
  },
  {
    title: "Formation Leadership - Executive Team",
    category: "SERVICES ÉDUCATIFS",
    description: "Programme de formation leadership sur mesure pour équipe dirigeante, incluant coaching individuel.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
    gradient: "from-orange-500 to-amber-400",
    results: ["Performance équipe +60%", "Satisfaction client 98%", "Innovation projects +30%"]
  }
];

const categories = ["TOUS", "STRATÉGIE DIGITALE", "IDENTITÉ VISUELLE", "GESTION DE CRISE", "SOLUTIONS RH", "DÉVELOPPEMENT WEB", "SERVICES ÉDUCATIFS"];

export default function Portfolio() {
  const [selectedCategory, setSelectedCategory] = useState("TOUS");
  
  const filteredItems = selectedCategory === "TOUS" 
    ? portfolioItems 
    : portfolioItems.filter(item => item.category === selectedCategory);
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-b from-navy to-charcoal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">
              Notre <span className="text-gold">Portfolio</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
              Découvrez nos réalisations les plus marquantes et les résultats 
              exceptionnels obtenus pour nos clients.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <Badge
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                className={`cursor-pointer px-4 py-2 transition-all ${
                  selectedCategory === category
                    ? "bg-gold text-navy hover:bg-gold/90"
                    : "border-gold text-gold hover:bg-gold hover:text-navy"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="grid lg:grid-cols-2 gap-12"
            key={selectedCategory}
          >
            {filteredItems.map((item, index) => (
              <motion.div
                key={`${item.title}-${selectedCategory}`}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <PortfolioItem item={item} detailed />
              </motion.div>
            ))}
          </motion.div>

          {filteredItems.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <p className="text-xl text-charcoal">
                Aucun projet trouvé pour cette catégorie.
              </p>
            </motion.div>
          )}
        </div>
      </section>

      {/* Success Stories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Témoignages <span className="text-gold">Clients</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Ce que disent nos clients de notre collaboration et des résultats obtenus.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                quote: "ALRC Groupe a transformé notre communication digitale. Leur expertise et leur approche stratégique ont dépassé nos attentes.",
                author: "Alain K.",
                role: "Directeur Communication, Groupe Élan",
                company: "Groupe Élan"
              },
              {
                quote: "Grâce à ALRC, nous avons réussi notre levée de fonds. Leur travail sur notre identité visuelle a été déterminant.",
                author: "Sarah M.",
                role: "CEO, Tech Innovate",
                company: "Tech Innovate"
              },
              {
                quote: "Leur gestion de crise a sauvé notre réputation. Professionnalisme et efficacité au rendez-vous.",
                author: "Michel L.",
                role: "Directeur Général, Luxury Hotels",
                company: "Luxury Hotels"
              }
            ].map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-gray-50 rounded-2xl p-8 luxury-shadow"
              >
                <div className="text-gold text-4xl mb-4">"</div>
                <p className="text-charcoal text-lg mb-6 italic">
                  {testimonial.quote}
                </p>
                <div>
                  <div className="font-semibold text-navy">
                    {testimonial.author}
                  </div>
                  <div className="text-sm text-charcoal">
                    {testimonial.role}
                  </div>
                  <div className="text-sm text-gold font-medium">
                    {testimonial.company}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-navy">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-white mb-6">
              Votre Projet Sera le <span className="text-gold">Prochain Succès</span>
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              Rejoignez nos clients satisfaits et transformez vos défis en opportunités 
              avec notre expertise intégrée.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/contact">
                <Button className="bg-gold text-navy hover:bg-gold/90 px-8 py-4 text-lg">
                  Démarrer Votre Projet
                </Button>
              </Link>
              <Link href="/services">
                <Button variant="outline" className="border-white text-white hover:bg-white hover:text-navy px-8 py-4 text-lg">
                  Découvrir nos Services
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
