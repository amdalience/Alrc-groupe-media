import { motion } from "framer-motion";
import Navbar from "@/components/layout/navbar";
import Footer from "@/components/layout/footer";
import ContactForm from "@/components/contact-form";
import FAQSection from "@/components/faq-section";
import { Card, CardContent } from "@/components/ui/card";

export default function Contact() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-b from-navy to-charcoal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-8">
              Contactez-<span className="text-gold">Nous</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-4xl mx-auto">
              Prêt à transformer votre communication ? Parlons de votre projet 
              et découvrez comment nous pouvons vous accompagner.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-8">
                Transformons Ensemble Vos <span className="text-gold">Ambitions</span>
              </h2>
              <p className="text-xl text-charcoal mb-12">
                Bénéficiez d'une consultation gratuite avec nos experts. 
                Nous analysons vos besoins et vous proposons une stratégie sur mesure.
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy text-xl">📍</span>
                  </div>
                  <div>
                    <h4 className="text-navy font-semibold mb-2">Nos Bureaux</h4>
                    <p className="text-charcoal">142 rue de Rivoli, 75015 Paris</p>
                    <p className="text-charcoal">4 Rue Aristide Maillol, 75015 Paris</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy text-xl">📞</span>
                  </div>
                  <div>
                    <h4 className="text-navy font-semibold mb-2">Contact Direct</h4>
                    <p className="text-charcoal">+33 7 67 03 48 XX</p>
                    <p className="text-charcoal">Disponible 24/7</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy text-xl">✉️</span>
                  </div>
                  <div>
                    <h4 className="text-navy font-semibold mb-2">Email</h4>
                    <p className="text-charcoal">contact@groupe-alrc.org</p>
                    <p className="text-charcoal">Réponse sous 2h</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-navy text-xl">🏢</span>
                  </div>
                  <div>
                    <h4 className="text-navy font-semibold mb-2">Informations Légales</h4>
                    <p className="text-charcoal">SIREN: 827984568</p>
                    <p className="text-charcoal">Capital social: 10 000€</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <ContactForm />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
              Venez Nous <span className="text-gold">Rencontrer</span>
            </h2>
            <p className="text-xl text-charcoal max-w-3xl mx-auto">
              Nos bureaux parisiens vous accueillent dans un cadre moderne et inspirant, 
              idéal pour échanger sur vos projets.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            <Card className="luxury-shadow">
              <CardContent className="p-8">
                <h3 className="text-2xl font-serif font-bold text-navy mb-4">
                  Bureau Principal
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">📍</span>
                    <div>
                      <p className="font-semibold text-navy">142 rue de Rivoli</p>
                      <p className="text-charcoal">75015 Paris, France</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">🕒</span>
                    <div>
                      <p className="font-semibold text-navy">Horaires</p>
                      <p className="text-charcoal">Lun-Ven: 9h-18h</p>
                      <p className="text-charcoal">Sam: 9h-12h sur RDV</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">🚇</span>
                    <div>
                      <p className="font-semibold text-navy">Transports</p>
                      <p className="text-charcoal">Métro: Trocadéro (L6, L9)</p>
                      <p className="text-charcoal">Bus: 22, 30, 32</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="luxury-shadow">
              <CardContent className="p-8">
                <h3 className="text-2xl font-serif font-bold text-navy mb-4">
                  Bureau Secondaire
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">📍</span>
                    <div>
                      <p className="font-semibold text-navy">4 Rue Aristide Maillol</p>
                      <p className="text-charcoal">75015 Paris, France</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">🕒</span>
                    <div>
                      <p className="font-semibold text-navy">Horaires</p>
                      <p className="text-charcoal">Lun-Ven: 9h-17h</p>
                      <p className="text-charcoal">Sur rendez-vous uniquement</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <span className="text-gold mt-1">🚇</span>
                    <div>
                      <p className="font-semibold text-navy">Transports</p>
                      <p className="text-charcoal">Métro: Bir-Hakeim (L6)</p>
                      <p className="text-charcoal">RER: Champ de Mars (RER C)</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <FAQSection />

      <Footer />
    </div>
  );
}
