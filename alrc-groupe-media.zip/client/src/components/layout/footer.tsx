import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-charcoal text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="text-2xl font-serif font-bold mb-6">
              ALRC<span className="text-gold">.</span>Groupe
            </div>
            <p className="text-gray-400 mb-6">
              Votre partenaire de confiance pour une communication stratégique intégrée. 
              Excellence, innovation et résultats mesurables.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-navy rounded-full flex items-center justify-center hover:bg-gold hover:text-navy transition-all">
                <span>📧</span>
              </a>
              <a href="#" className="w-10 h-10 bg-navy rounded-full flex items-center justify-center hover:bg-gold hover:text-navy transition-all">
                <span>💼</span>
              </a>
              <a href="#" className="w-10 h-10 bg-navy rounded-full flex items-center justify-center hover:bg-gold hover:text-navy transition-all">
                <span>🐦</span>
              </a>
              <a href="#" className="w-10 h-10 bg-navy rounded-full flex items-center justify-center hover:bg-gold hover:text-navy transition-all">
                <span>📷</span>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-6">Services</h4>
            <ul className="space-y-3 text-gray-400">
              <li><Link href="/services" className="hover:text-gold transition-colors">Communication Stratégique</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Digital & Social Media</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Création & Design</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Solutions RH</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Web & Hébergement</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-6">Expertise</h4>
            <ul className="space-y-3 text-gray-400">
              <li><Link href="/services" className="hover:text-gold transition-colors">Services Éducatifs</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Conseil Financier</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Intégration Technologique</Link></li>
              <li><Link href="/services" className="hover:text-gold transition-colors">Gestion de Crise</Link></li>
              <li><Link href="/portfolio" className="hover:text-gold transition-colors">Portfolio</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-6">Contact</h4>
            <div className="space-y-3 text-gray-400">
              <p>142 rue de Rivoli<br />75015 Paris, France</p>
              <p>+33 7 67 03 48 XX</p>
              <p>contact@groupe-alrc.org</p>
              <p className="text-gold font-semibold">Support 24/7</p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 ALRC Groupe Média. Tous droits réservés. SIREN 827984568
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 text-sm hover:text-gold transition-colors">Mentions Légales</a>
              <a href="#" className="text-gray-400 text-sm hover:text-gold transition-colors">Politique de Confidentialité</a>
              <a href="#" className="text-gray-400 text-sm hover:text-gold transition-colors">Conditions d'Utilisation</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
