import { Card, CardContent } from "@/components/ui/card";

interface TeamMemberProps {
  member: {
    name: string;
    role: string;
    description: string;
    image: string;
    icon: string;
  };
}

export default function TeamMember({ member }: TeamMemberProps) {
  return (
    <div className="text-center group">
      <div className="relative mb-6">
        <img 
          src={member.image} 
          alt={`Portrait professionnel de ${member.name}`}
          className="w-32 h-32 rounded-full mx-auto luxury-shadow object-cover group-hover:scale-105 transition-transform" 
        />
        <div className="absolute -bottom-2 -right-2 bg-gold rounded-full p-2">
          <span className="text-navy text-sm">{member.icon}</span>
        </div>
      </div>
      <h3 className="text-xl font-serif font-bold text-navy mb-2">
        {member.name}
      </h3>
      <p className="text-gold font-semibold mb-3">
        {member.role}
      </p>
      <p className="text-sm text-charcoal mb-4">
        {member.description}
      </p>
      <div className="flex justify-center space-x-3">
        <a href="#" className="text-charcoal hover:text-gold transition-colors">
          <span className="text-lg">💼</span>
        </a>
        <a href="#" className="text-charcoal hover:text-gold transition-colors">
          <span className="text-lg">🐦</span>
        </a>
      </div>
    </div>
  );
}
