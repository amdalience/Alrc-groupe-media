import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

interface SkillBadgeProps {
  skill: string;
  level?: "expert" | "avance" | "intermediaire";
  delay?: number;
}

export default function SkillBadge({ skill, level = "expert", delay = 0 }: SkillBadgeProps) {
  const variants = {
    expert: "bg-gold text-navy",
    avance: "bg-blue-500 text-white", 
    intermediaire: "bg-gray-500 text-white"
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4, delay }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.05 }}
    >
      <Badge className={`${variants[level]} hover:shadow-lg transition-all duration-200`}>
        {skill}
      </Badge>
    </motion.div>
  );
}