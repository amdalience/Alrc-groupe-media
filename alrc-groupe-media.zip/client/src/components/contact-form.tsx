import { useState } from "react";
import { motion } from "framer-motion";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ContactFormData {
  firstName: string;
  lastName: string;
  email: string;
  company: string;
  service: string;
  message: string;
}

const services = [
  { value: "strategic", label: "Communication Stratégique" },
  { value: "digital", label: "Digital & Réseaux Sociaux" },
  { value: "creative", label: "Création & Design" },
  { value: "hr", label: "Solutions RH" },
  { value: "web", label: "Web & Hébergement" },
  { value: "education", label: "Services Éducatifs" },
  { value: "financial", label: "Conseil Financier" },
  { value: "technology", label: "Intégration Technologique" },
];

export default function ContactForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState<ContactFormData>({
    firstName: "",
    lastName: "",
    email: "",
    company: "",
    service: "",
    message: "",
  });
  
  const [consent, setConsent] = useState(false);

  const mutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return apiRequest("POST", "/api/contacts", data);
    },
    onSuccess: () => {
      toast({
        title: "Message envoyé avec succès!",
        description: "Nous vous répondrons dans les plus brefs délais.",
      });
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        company: "",
        service: "",
        message: "",
      });
      setConsent(false);
      queryClient.invalidateQueries({ queryKey: ["/api/contacts"] });
    },
    onError: (error) => {
      toast({
        title: "Erreur lors de l'envoi",
        description: "Une erreur est survenue. Veuillez réessayer.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!consent) {
      toast({
        title: "Consentement requis",
        description: "Veuillez accepter d'être contacté pour continuer.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.firstName || !formData.lastName || !formData.email || !formData.service) {
      toast({
        title: "Champs requis manquants",
        description: "Veuillez remplir tous les champs obligatoires.",
        variant: "destructive",
      });
      return;
    }

    mutation.mutate(formData);
  };

  const handleInputChange = (field: keyof ContactFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      viewport={{ once: true }}
    >
      <Card className="luxury-shadow">
        <CardHeader>
          <CardTitle className="text-2xl font-serif font-bold text-navy">
            Consultation Gratuite
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-charcoal mb-2">
                  Prénom *
                </label>
                <Input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange("firstName", e.target.value)}
                  placeholder="Votre prénom"
                  className="focus:ring-2 focus:ring-gold focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-charcoal mb-2">
                  Nom *
                </label>
                <Input
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange("lastName", e.target.value)}
                  placeholder="Votre nom"
                  className="focus:ring-2 focus:ring-gold focus:border-transparent"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-charcoal mb-2">
                Email Professionnel *
              </label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="contact@votre-entreprise.com"
                className="focus:ring-2 focus:ring-gold focus:border-transparent"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-charcoal mb-2">
                Entreprise
              </label>
              <Input
                type="text"
                value={formData.company}
                onChange={(e) => handleInputChange("company", e.target.value)}
                placeholder="Nom de votre entreprise"
                className="focus:ring-2 focus:ring-gold focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-charcoal mb-2">
                Service d'Intérêt *
              </label>
              <Select value={formData.service} onValueChange={(value) => handleInputChange("service", value)}>
                <SelectTrigger className="focus:ring-2 focus:ring-gold focus:border-transparent">
                  <SelectValue placeholder="Sélectionnez un service" />
                </SelectTrigger>
                <SelectContent>
                  {services.map((service) => (
                    <SelectItem key={service.value} value={service.value}>
                      {service.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-charcoal mb-2">
                Décrivez votre Projet
              </label>
              <Textarea
                value={formData.message}
                onChange={(e) => handleInputChange("message", e.target.value)}
                rows={4}
                placeholder="Parlez-nous de vos objectifs et défis..."
                className="focus:ring-2 focus:ring-gold focus:border-transparent"
              />
            </div>
            
            <div className="flex items-start space-x-3">
              <Checkbox
                id="consent"
                checked={consent}
                onCheckedChange={(checked) => setConsent(checked as boolean)}
                className="mt-1"
              />
              <label htmlFor="consent" className="text-sm text-charcoal">
                J'accepte d'être contacté par ALRC Groupe pour recevoir des informations sur leurs services.{" "}
                <a href="#" className="text-gold hover:underline">
                  Politique de confidentialité
                </a>
              </label>
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-gold text-navy hover:bg-gold/90 py-4 text-lg font-semibold luxury-shadow"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Envoi en cours..." : "Demander une Consultation Gratuite"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </motion.div>
  );
}
