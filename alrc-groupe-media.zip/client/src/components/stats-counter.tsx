import { useState, useEffect } from "react";
import { motion } from "framer-motion";

interface StatsCounterProps {
  target: number;
  label: string;
  suffix?: string;
  duration?: number;
}

export default function StatsCounter({ target, label, suffix = "", duration = 2000 }: StatsCounterProps) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!isVisible) return;

    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      setCount((prev) => {
        const next = prev + increment;
        if (next >= target) {
          clearInterval(timer);
          return target;
        }
        return next;
      });
    }, 16);

    return () => clearInterval(timer);
  }, [isVisible, target, duration]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      viewport={{ once: true }}
      onViewportEnter={() => setIsVisible(true)}
      className="text-center"
    >
      <div className="text-4xl md:text-5xl font-bold text-gold mb-2">
        {Math.floor(count)}{suffix}
      </div>
      <div className="text-white font-medium">
        {label}
      </div>
    </motion.div>
  );
}