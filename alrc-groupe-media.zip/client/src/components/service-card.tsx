import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface ServiceCardProps {
  service: {
    id: string;
    title: string;
    description: string;
    icon: string;
    gradient: string;
  };
}

export default function ServiceCard({ service }: ServiceCardProps) {
  return (
    <Card className="bg-gray-50 hover-lift luxury-shadow premium-border h-full">
      <CardContent className="p-8">
        <div className={`w-16 h-16 bg-gradient-to-br ${service.gradient} rounded-full flex items-center justify-center mb-6`}>
          <span className="text-2xl">{service.icon}</span>
        </div>
        <h3 className="text-xl font-serif font-bold text-navy mb-4">
          {service.title}
        </h3>
        <p className="text-charcoal mb-6">
          {service.description}
        </p>
        <Link href="/contact">
          <Button 
            variant="ghost" 
            className="text-gold hover:text-navy hover:bg-gold/10 p-0 h-auto font-semibold"
          >
            En savoir plus
            <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
