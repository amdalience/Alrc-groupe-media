import { Card, CardContent } from "@/components/ui/card";

interface PortfolioItemProps {
  item: {
    title: string;
    category: string;
    description: string;
    image: string;
    gradient: string;
    results?: string[];
  };
  detailed?: boolean;
}

export default function PortfolioItem({ item, detailed = false }: PortfolioItemProps) {
  return (
    <Card className="group cursor-pointer hover-lift overflow-hidden luxury-shadow">
      <div className={`h-64 bg-gradient-to-br ${item.gradient} relative overflow-hidden`}>
        <img 
          src={item.image} 
          alt={item.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
      </div>
      <CardContent className="p-8">
        <div className="text-sm text-gold font-semibold mb-2">
          {item.category}
        </div>
        <h3 className="text-xl font-serif font-bold text-navy mb-4">
          {item.title}
        </h3>
        <p className="text-charcoal mb-6">
          {item.description}
        </p>
        
        {detailed && item.results && (
          <div className="mb-6">
            <h4 className="text-sm font-semibold text-navy mb-3">Résultats obtenus :</h4>
            <ul className="space-y-2">
              {item.results.map((result, index) => (
                <li key={index} className="flex items-center space-x-2">
                  <span className="text-gold">✓</span>
                  <span className="text-sm text-charcoal">{result}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        
        <div className="flex items-center text-gold font-semibold group-hover:translate-x-2 transition-transform">
          <span>Voir l'étude de cas</span>
          <svg className="ml-2 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </div>
      </CardContent>
    </Card>
  );
}
