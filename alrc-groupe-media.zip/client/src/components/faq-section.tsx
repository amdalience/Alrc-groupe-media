import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const faqs = [
  {
    question: "Quels sont vos délais moyens de réalisation ?",
    answer: "Les délais varient selon le projet. Une stratégie de communication prend 2-4 semaines, un site web 4-8 semaines, et une campagne complète 6-12 semaines. Nous établissons un planning détaillé dès la première consultation."
  },
  {
    question: "Proposez-vous un accompagnement post-projet ?",
    answer: "Absolument ! Nous proposons différents niveaux d'accompagnement : support technique, formation des équipes, suivi des performances et optimisations continues. Notre objectif est votre réussite à long terme."
  },
  {
    question: "Comment mesurez-vous le ROI de vos actions ?",
    answer: "Nous définissons des KPI précis dès le début : taux de conversion, engagement, visibilité, leads générés, etc. Nos rapports mensuels incluent un dashboard complet avec analyses et recommandations."
  },
  {
    question: "Travaillez-vous avec des PME ou seulement des grands groupes ?",
    answer: "Nous accompagnons tous types d'entreprises, des startups aux multinationales. Nos solutions s'adaptent à votre budget et vos objectifs. 60% de nos clients sont des PME/ETI."
  },
  {
    question: "Quelle est votre approche en cas de crise ?",
    answer: "Notre cellule de crise est disponible 24/7. Nous intervenons en moins de 2h avec une stratégie de communication adaptée, gestion des médias, monitoring en temps réel et plan de restauration d'image."
  },
  {
    question: "Proposez-vous des formations pour nos équipes ?",
    answer: "Oui, nous proposons des formations sur mesure : communication digitale, gestion de crise, leadership, utilisation des outils... Format présentiel ou distanciel selon vos besoins."
  }
];

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-serif font-bold text-navy mb-6">
            Questions <span className="text-gold">Fréquentes</span>
          </h2>
          <p className="text-xl text-charcoal">
            Toutes les réponses à vos questions sur nos services et notre approche
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="luxury-shadow overflow-hidden">
                <CardContent className="p-0">
                  <button
                    onClick={() => setOpenIndex(openIndex === index ? null : index)}
                    className="w-full p-6 text-left hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-semibold text-navy pr-4">
                        {faq.question}
                      </h3>
                      <motion.div
                        animate={{ rotate: openIndex === index ? 180 : 0 }}
                        transition={{ duration: 0.3 }}
                        className="flex-shrink-0"
                      >
                        <svg
                          className="w-5 h-5 text-gold"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M19 9l-7 7-7-7"
                          />
                        </svg>
                      </motion.div>
                    </div>
                  </button>
                  
                  <AnimatePresence>
                    {openIndex === index && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="border-t border-gray-200"
                      >
                        <div className="p-6 pt-4">
                          <p className="text-charcoal leading-relaxed">
                            {faq.answer}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}